package Matrix;

public class Main {
	// driver Class
    public static void main(String[] args) {
        int[][] d = { { 1, 2, 3 }, { 4, 5, 6 }, { 9, 1, 3} };
        Matrix D = new Matrix(d);
        D.show();        
        System.out.println();

          Matrix B = A.transpose();
        B.show(); 
        System.out.println();

        Matrix C = Matrix.identity(5);
        C.show(); 
        System.out.println();

        A.plus(B).show();
        System.out.println();


        // shouldn't be equal since AB != BA in general    
        System.out.println(A.times(B).eq(B.times(A)));
        System.out.println();



        Matrix x = A.solve(b);
        x.show();
        System.out.println();

        A.times(x).show();
        
    }
}
